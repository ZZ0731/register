let vm=new Vue({
	el:'#userLogin',
	data:{
		uname:"",
		upassword:"",
		disabled:"true",
		submit:"cursor:pointer;",
		submitchangColor:"background-color:#EE7700;cursor:pointer;",
		disabled:true,
		abled:false

	},
	mounted(){
		if(this.uname&&this.upassword){
			this.submit ="background-color:#EE7700;cursor:pointer;";
		}
	},
	watch: {
		uname(newName, oldName) {
			if(this.uname&&this.upassword){
				this.submit ="background-color:#EE7700;cursor:pointer;";
			}		  
		},
		upassword(newName, oldName) {
			if(this.uname&&this.upassword){
				this.submit ="background-color:#EE7700;cursor:pointer;";
			}		  
		}
	} ,
	computed:{
		<!--計算backgroundcolor-->
		compClass:function(){
			if(this.uname&&this.upassword){
				return this.submitchangColor;
			}else{
				return this.submit;
			}
		},
		compdisabled:function(){
			if(this.uname&&this.upassword){
				return this.abled;
			}else{
				return this.disabled;
			}
		}
	}
});
